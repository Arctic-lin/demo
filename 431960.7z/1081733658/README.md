# Wallpaper Bar Visualizer
This project is made to work with Wallpaper Engine; a Steam desktop application that enables users to set web-based applications as their Windows Desktop background.

## This project container several GIT Modules
This project is build using GIT Modules. This project uses the following Modules made by Arthesian:
* Visualizer
* Visuals
* Clock
* Perspective

These are seperate GIT repositories, that are maintained on their own. Once a new version is released of these modules, it is possible to easily pull the changes into this project.

NOTE: This project does not use templating/rendering/building software like Gulp or Grunt, but the submodules do. Read the matching readme.md file corresponding with the module, if you want to edit it ( and or commit changes ).