/// <reference path="modules/perspective.ts" />

var perspective = new Perspective(".block");